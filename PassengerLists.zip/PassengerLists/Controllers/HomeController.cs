﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PassengerLists.Models;
using System.Data.Entity;
using System.Net;


namespace PassengerLists.Controllers
{
    public class HomeController : Controller
    {
 
        // declares database connection

        private PassengerDBEntities db = new PassengerDBEntities();



        // ---------------------- Passenger Records -------------------------------------------
        //Index page - Displays the passenger records from the passenger table in the database - using p as passengers starts with p
        public ActionResult Index(string searchString)
        {

            var Passengers = from p in db.Passengers
                             select p;


            // code so that the user can search for passengers by their surname
            if (!String.IsNullOrEmpty(searchString))
            {
                Passengers = Passengers.Where(x => x.Surname.Contains(searchString));
            }

            return View(Passengers);
        }

        // ------- CRUD functionalty for the Passenger Records ----------

        // Create new passenger record page set up  

        public ActionResult Create()
        {
            return View();
        }

        // Code to save new passenger record to the database 

        [HttpPost]
        public ActionResult Create(Passenger passenger)
        {

            // code so that record will only save if user input meets all validation rules
            if (ModelState.IsValid)
            {
                db.Passengers.Add(passenger);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(passenger);
        }


        // Read the passenger detail

        public ActionResult Details(int? id)
        {
            // if statement so that if an invalid id is entered an error page will be displayed 
            if (id== null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            Passenger passenger = db.Passengers.Find(id);


            // if statement so that if a rocord that doesnt exist is entered an error page will be displayed  
            if (passenger== null)
            {
                return HttpNotFound();
            }
            return View(passenger);
        }


        // Update current record page set up 

        public ActionResult Edit (int id)
        {
            Passenger passenger = db.Passengers.Find(id);
            return View(passenger);
        }

        // Code to save record that has been updated
        [HttpPost]
        public ActionResult Edit(Passenger passenger)
        {
            // code so that record will only save if user input meets all validation rules
            if (ModelState.IsValid)
            {
                db.Entry(passenger).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(passenger);
        }



        // Delete record set up page

        public ActionResult Delete(int id)
        {
            Passenger passenger = db.Passengers.Find(id);

            return View(passenger);
        }

        // Code to delete record permanently from Database

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            Passenger passenger = db.Passengers.Find(id);
            db.Passengers.Remove(passenger);
            db.SaveChanges();
            return RedirectToAction("Index");
        }



        //-------------------------------- Arrival Records -----------------------------------------

        // ArrivalRecords page - Displays the arrival records from the arrival table in the database - using a as arrivals starts with a

        public ActionResult ArrivalRecords()
        {

            var Arrivals = from a in db.Arrivals
                             select a;                

            return View(Arrivals);
        }



        // ------- CRUD functionalty for the Passenger Records ----------

        // Create new passenger record page set up  

        public ActionResult Create2()
        {
            return View();
        }

        // Code to save new passenger record to the database 

        [HttpPost]
        public ActionResult Create2(Arrival arrival)
        {
            // code so that record will only save if user input meets all validation rules
            if (ModelState.IsValid)
            {
                db.Arrivals.Add(arrival);
                db.SaveChanges();
                return RedirectToAction("ArrivalRecords");
            }
            return View(arrival);
        }


        // Read the passenger detail

        public ActionResult Details2(int? id)
        {

            // if statement so that if an invalid id is entered an error page will be displayed 
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Arrival arrival = db.Arrivals.Find(id);

            // if statement so that if a rocord that doesnt exist is entered an error page will be displayed  
            if (arrival == null)
            {
                return HttpNotFound();
            }

            return View(arrival);
        }


        // Update current record page set up 

        public ActionResult Edit2(int id)
        {
            Arrival arrival = db.Arrivals.Find(id);
            return View(arrival);
        }

        // Code to save record that has been updated
        [HttpPost]
        public ActionResult Edit2(Arrival arrival)
        {
            // code so that record will only save if user input meets all validation rules
            if (ModelState.IsValid)
            {
                db.Entry(arrival).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("ArrivalRecords");
            }
            return View(arrival);
        }



        // Delete record set up page

        public ActionResult Delete2(int id)
        {
            Arrival arrival = db.Arrivals.Find(id);
            return View(arrival);
        }

        // Code to delete record permanently from Database

        [HttpPost, ActionName("Delete2")]
        public ActionResult DeleteConfirmed2(int id)
        {
            Arrival arrival = db.Arrivals.Find(id);
            db.Arrivals.Remove(arrival);
            db.SaveChanges();
            return RedirectToAction("ArrivalRecords");
        }


        // ---------------------- Ship Records -------------------------------------------
        //Index page - Displays the Ship records from the ship table in the database --- using s as ships starts with s
        public ActionResult ShipRecords()
        {

            var Ships = from s in db.Ships
                             select s;

            return View(Ships);
        }

        // ------- CRUD functionalty for the Ship Records ----------

        // Create new ship record page set up  

        public ActionResult Create3()
        {
            return View();
        }

        // Code to save new ship record to the database 

        [HttpPost]
        public ActionResult Create3(Ship ship)
        {
            // code so that record will only save if user input meets all validation rules
            if (ModelState.IsValid)
            {
                db.Ships.Add(ship);
                db.SaveChanges();
                return RedirectToAction("ShipRecords");
            }
            return View(ship);
        }


        // Read the ship detail

        public ActionResult Details3(int? id)
        {
            // if statement so that if an invalid id is entered an error page will be displayed 
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Ship ship = db.Ships.Find(id);

            // if statement so that if a rocord that doesnt exist is entered an error page will be displayed  
            if (ship == null)
            {
                return HttpNotFound();
            }
            return View(ship);
        }


        // Update current record page set up 

        public ActionResult Edit3(int id)
        {
            Ship ship = db.Ships.Find(id);
            return View(ship);
        }

        // Code to save record that has been updated
        [HttpPost]
        public ActionResult Edit3(Ship ship)
        {
            // code so that record will only save if user input meets all validation rules
            if (ModelState.IsValid)
            {
                db.Entry(ship).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("ShipRecords");
            }
            return View(ship);
        }



        // Delete record set up page

        public ActionResult Delete3(int id)
        {
            Ship ship = db.Ships.Find(id);

            return View(ship);
        }

        // Code to delete record permanently from Database

        [HttpPost, ActionName("Delete3")]
        public ActionResult DeleteConfirmed3(int id)
        {
            Ship ship = db.Ships.Find(id);
            db.Ships.Remove(ship);
            db.SaveChanges();
            return RedirectToAction("ShipRecords");
        }

    }

}